using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("References")]
    public Transform core;
    public GameObject spikePrefab;
    public TextMeshProUGUI scoreText;

    [Header("Spawn settings")]
    public float initialSpawnInterval = 0.6f;
    public float minSpawnInterval = 0.2f;
    public float spawnIntervalDecrease = 0.01f;

    [Header("Spike settings")]
    public float baseSpikeSpeed = 4f;

    private float spawnTimer = 0f;
    private float currentSpawnInterval;
    private int score = 0;
    private bool isGameOver = false;

    void Start()
    {
        currentSpawnInterval = initialSpawnInterval;
        UpdateScoreText();
    }

    void Update()
    {
        if (isGameOver) return;

        spawnTimer += Time.deltaTime;
        if (spawnTimer >= currentSpawnInterval)
        {
            spawnTimer = 0f;
            SpawnSpike();

            // Make it slowly harder
            if (currentSpawnInterval > minSpawnInterval)
                currentSpawnInterval -= spawnIntervalDecrease;
        }
    }

    void SpawnSpike()
    {
        // Pick a random edge of the screen
        Vector2 spawnPos = GetRandomEdgePosition();
        GameObject spikeObj = Instantiate(spikePrefab, spawnPos, Quaternion.identity);

        Spike spike = spikeObj.GetComponent<Spike>();
        spike.Init(core.position, baseSpikeSpeed, this);
    }

    Vector2 GetRandomEdgePosition()
    {
        // Convert screen edges to world positions
        float zDistance = Mathf.Abs(Camera.main.transform.position.z);

        Vector3 topLeft = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, zDistance));
        Vector3 bottomRight = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, zDistance));

        float left = topLeft.x;
        float right = bottomRight.x;
        float top = topLeft.y;
        float bottom = bottomRight.y;

        int side = Random.Range(0, 4); // 0=top,1=bottom,2=left,3=right
        switch (side)
        {
            case 0: // top
                return new Vector2(Random.Range(left, right), top + 0.5f);
            case 1: // bottom
                return new Vector2(Random.Range(left, right), bottom - 0.5f);
            case 2: // left
                return new Vector2(left - 0.5f, Random.Range(bottom, top));
            default: // right
                return new Vector2(right + 0.5f, Random.Range(bottom, top));
        }
    }

    public void AddScore(int amount)
    {
        if (isGameOver) return;
        score += amount;
        UpdateScoreText();
    }

    void UpdateScoreText()
    {
        if (scoreText != null)
            scoreText.text = "Score: " + score.ToString();
    }

    public void GameOver()
    {
        isGameOver = true;
        // TODO: later add UI panel for restart.
        Debug.Log("Game Over! Final Score: " + score);
    }
}
