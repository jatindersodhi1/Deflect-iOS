using UnityEngine;

public class Spike : MonoBehaviour
{
    private Vector3 targetPosition;
    private float speed;
    private GameManager gameManager;
    private bool initialized = false;

    public void Init(Vector3 target, float baseSpeed, GameManager gm)
    {
        targetPosition = target;
        gameManager = gm;
        speed = baseSpeed;
        initialized = true;

        // Point toward core
        Vector3 dir = (targetPosition - transform.position).normalized;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    void Update()
    {
        if (!initialized) return;

        Vector3 dir = (targetPosition - transform.position).normalized;
        transform.position += dir * speed * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!initialized) return;

        if (other.CompareTag("Shield"))
        {
            // deflected: add score and destroy
            gameManager.AddScore(10);
            Destroy(gameObject);
        }
        else if (other.CompareTag("Core"))
        {
            // hit core: game over
            gameManager.GameOver();
            Destroy(gameObject);
        }
    }
}
