using UnityEngine;

public class ShieldController : MonoBehaviour
{
    public Transform core;
    public float radius = 2f;

    void Update()
    {
        if (core == null) return;

        // Mouse (hold + drag)
        if (Input.GetMouseButton(0))
        {
            Vector3 mouseWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            mouseWorld.z = 0;
            RotateAroundCore(mouseWorld);
        }

        // Touch (iPhone / single finger drag)
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            Vector3 touchWorld = Camera.main.ScreenToWorldPoint(touch.position);
            touchWorld.z = 0;
            RotateAroundCore(touchWorld);
        }
    }

    void RotateAroundCore(Vector3 targetPos)
    {
        Vector3 dir = (targetPos - core.position).normalized;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        transform.position = core.position + dir * radius;
    }
}
